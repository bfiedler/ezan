#!/usr/bin/env python
# v0.2 13 October 2008
#plots time histories of maxima stored in eza.hist files in subdirectories
#example of usage:
#>  plothist.py -o both.png exp1_subdirectory exp2_subdirectory
#To see a GUI, and not maka a PNG,
#>  plothist.py exp1_subdirectory exp2_subdirectory
import sys
from pylab import *  #pylab is the same as matplotlib.pylab
from optparse import OptionParser
usage="usage: %prog DATAFILE   [options]"
parser = OptionParser(usage=usage, version="%prog 0.1")
parser.add_option("-t", dest="title",type="string",help="title string",default=None)
parser.add_option("-o", dest="outputfile",type="string",help="output filename",default=None)
parser.add_option("--dpi", dest="dpi",type="int",help="dotsperinch",default=72)
parser.add_option("--x1", dest="x1",type="float",help="left plot window x limit",default=None)
parser.add_option("--x2", dest="x2",type="float",help="right plot window x limit",default=None)
parser.add_option("--y1", dest="y1",type="float",help="top plot window x limit",default=-2)
parser.add_option("--y2", dest="y2",type="float",help="lower plot window x limit",default=2)
(opt, args) = parser.parse_args()
dotsperinch=opt.dpi
dotsperinch=72
#hold(True)
directories=args
legendlabs=[]
markers=['','--',':'] # dash patterns for black and and white plots
nf=0
for directory in directories:
	inf=open(directory+'/eza.hist','r')
	all=inf.readlines()
	inf.close()
	hist=all[100:]
	t=[]
	u=[]
	v=[]
	w=[]
	p=[]
	bp=[]
	for line in hist:
		line=line.strip()
		a=line.split()
		a=[float(x) for x in a]
		t.append(a[0])
		u.append(a[2])
		v.append(a[3])
		w.append(a[4])
		p.append(a[5])
		bp.append(a[7])
#	print(directory,len(t),len(v),len(w))
	m=markers[nf]
	plot(t,u,'m'+m,t,v,'b'+m,t,w,'r'+m,t,p,'g'+m,linewidth=2)
	#plot(t,u,'m'+m,t,v,'b'+m,t,w,'r'+m,t,p,'g'+m,t,bp,'y'+m,linewidth=2)
	#plot(t,v,'k',t,w,'k:',t,p,'k--',linewidth=2) #for b&w
	nf+=1
	legendlabs+=['u','v','w','p']
legend(legendlabs,loc='best')
if opt.x1 or opt.x2:
	if not opt.x1:
		opt.x1=min(t)
	if not opt.x2:
		opt.x2=max(t)
	xlim([opt.x1,opt.x2])
ylim([opt.y1,opt.y2])
grid(True)
xlabel('t')
if opt.title:
	title(opt.title)
else:
	title(', '.join(directories))
if opt.outputfile:
	savefig(opt.outputfile, dpi=dotsperinch, facecolor='w', edgecolor='w', orientation='portrait')
else:
	show()
