#!/usr/bin/env python
# ./mpeza.py -c intense/eza017400.dat -o pngs/017400.png
from glob import glob
import os
import sys
choice=int(sys.argv[1])
if choice == 1:
    dd='noslip/'
    pd='noslip_pngs/'

elif choice == 2:
    dd='intense/'
    pd='intense_pngs/'
else:
    sys.exit("you need to append a 1 or 2")
datafiles=glob(dd+'*.dat')
datafiles.sort()
for file in datafiles:
    t=file[-10:-4]
    oup=pd+t+'.png'
    if choice == 1:
        command='./mpeza.py '+file+' -o '+oup
    else:
        command='./mpeza.py -g -x .05 -y .1  '+file+' -d'+" '.1 .2 .35 1.'"+' -o '+oup
    print(command)
    os.system(command)


