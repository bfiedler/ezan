def niceColors(v,colorname='default'):
	v=max(v,0.)
	v=min(v,1.)
	if colorname=='cyan_magenta':
		green=1-v
		red=v
		blue=2*(max(green,red)-.5)
	elif colorname=='grey':
		green=v*(1-v)*4
		red=green
		blue=green
	elif colorname=='cyan_yellow':
		red=v
		blue=1-v
		green=max(red,blue)
	elif colorname=='cyan_mud_yellow':
		red=v
		blue=1-v
		green=max(red,blue)
		red=sqrt(red)
	elif colorname=='step':
		green=0
		if v>0.5:
			blue=1
			red=0
		else:
			blue=0
			red=1
	elif colorname=='fruity':
		ig=int(3*v)
		if ig==0:
			blue=1-.5*v
			green=3*v
			red=1.5*v+.5
		elif ig==1:
			blue=1-.5*v-.25
			green=2.-3*v
			red=.5*v+.25
		else:
			blue=1-.5*v-.5
			red=.5*v+.5
			green=3*v-2.
	elif colorname=='centerwhite':
		if (v < .5 ):
			q=(2*v)
			ex=q+(1-q)*.5
			q=q**ex
			red=12*(q*q*q/3-q*q/2+q/4)
			blue=1.
			green=3*q*q*(1-2*q/3)
		else: 
			s=(2-2*v)
			ex=s+(1-s)*.5
			s=s**ex
			blue=12*(s*s*s/3-s*s/2+s/4)
			red=1.
			green=3*s*s*(1-2*s/3)
	else:
		if not colorname=='default':
			print(colorname+' unknown, revert to default')
		red=v
		blue=1-v
		ig=int(v*4)
		if ig==0:
			green=1-4*v
		elif ig==1:
			green=2*(v-.25)
		elif ig==2:
			green=.5-2*(v-.5)
		else:
			green=4*(v-.75)
#	print colorname,v,red,green,blue
	return (red,green,blue)
#######################################################
